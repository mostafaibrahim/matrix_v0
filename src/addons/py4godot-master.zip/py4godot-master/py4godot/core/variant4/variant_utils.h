#include "gdextension_interface.h"
#include<stdio.h>
#include<stdlib.h>
void* vector_array;
int int_val = 0;
float float_val = 0;
int bool_val = 0;

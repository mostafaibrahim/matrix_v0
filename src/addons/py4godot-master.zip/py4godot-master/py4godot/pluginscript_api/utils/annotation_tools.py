import importlib


def load(loader):
    return loader.load_module()

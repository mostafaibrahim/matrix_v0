#pragma once

namespace godot{

    void init_py_language();
    void deinit_py_language();
}

from py4godot.pluginscript_api.utils.annotations import private as gd_private

def private(func):
    return gd_private(func)
/*#include "gdnative_api_struct.gen.h"

static const godot_gdnative_core_api_struct* api_core;
static const godot_gdnative_ext_nativescript_api_struct *nativescript_api;
static const godot_gdnative_ext_nativescript_1_1_api_struct *nativescript_api_11;

//members for bindings funcs
int language_index;
godot_instance_binding_functions binding_funcs;

void set_api_core(godot_gdnative_core_api_struct* core){
    printf("binding set core\n");
    printf("get_pointer:");
    printf("%p \n", core);
    printf("\n");
    api_core = core;
}

godot_gdnative_core_api_struct* get_core(){
    printf("binding get core\n");
    printf("get_pointer:");
    printf("%p \n", api_core);
    printf("\n");
    return api_core;
}

void print_ptr(void* owner)
{
   printf("%p \n", owner);
}
*/